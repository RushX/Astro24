<?php
$razorkey_id='rzp_test_JX9HznGVSID2XK';
$razorkey_secret='3ap160vXpurQlqt8W5DtbG0n';
$AstrouserId = "618859";
$AstroapiKey = "ad7cb5518b5f322a4f9f2d89ae5d399e";
$Encr_key="18768";
$sheetId='13JaaocSypBRmSd0MAQ4WpGqmdnOXYRfx11NIyz04I4A';

$refs=["RM096"=>50];

?>